var postcsssimplevar = require('postcss-simple-vars');
var postcssrgbafallback = require('postcss-color-rgba-fallback');
var autoprefixer = require('autoprefixer');
var animation = require('postcss-animation')

module.exports = {
    plugins:[
        // postcsssimplevar()
        // postcssrgbafallback()
       // autoprefixer({overrideBrowserslist:'last 30 version'})
       animation()
    ]
}