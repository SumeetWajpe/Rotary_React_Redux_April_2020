import React from 'react';
import ProductModel from './product.model';

interface IProductProps {
    productdetails: ProductModel;
}
interface IProductState {
    currLikes: number
}
//React.Component<PropTypes,StateTypes>
export default class Product extends
    React.Component<IProductProps, IProductState>{
    constructor(props: IProductProps) {
        //console.log('Inside constructor of Products')
        super(props);
        this.state = { currLikes: this.props.productdetails.likes };
    }
    static defaultProps = {
        productdetails: new ProductModel(0,"Unknown", 0, "https://www.indiaspora.org/wp-content/uploads/2018/10/image-not-available.jpg", 0, 0, 0)
    }
    IncrementLikes() {
        // this.props.productdetails.likes+=1; // props are readonly !!
        // update the state !
        //this.state.count+=1; // state is immutable !!
        this.setState({ currLikes: this.state.currLikes + 1 });
    }
    
    render() {
        return <div className="col-md-4">
            <div className="ProductStyle">
                <h1>{this.props.productdetails.name} </h1>
                <img src={this.props.productdetails.imageUrl} height="200px" width="200px" /> <br />
                <h4>Price: {this.props.productdetails.price}</h4>
                <h4>Rating: {this.props.productdetails.rating}</h4>
                <h4>Quantity: {this.props.productdetails.quantity} </h4>
                <button className="btn btn-primary" onClick={this.IncrementLikes.bind(this)}>
                    <span className="glyphicon glyphicon-thumbs-up">

                    </span>
                    {/* {this.props.productdetails.likes} */}
                    {this.state.currLikes}
                </button>
                <button className="btn btn-danger"               >
                 {/* onClick={this.props.DeleteHandler.bind(this,this.props.productdetails.id)}> */}          

                    <span className="glyphicon glyphicon-trash">

                    </span>
                </button>
            </div>
        </div>

    }
}