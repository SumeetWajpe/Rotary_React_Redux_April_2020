var products = [{"id":1,"name":"LED TV","price":40000,"imageUrl":"https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg","likes":100,"rating":3,"quantity":200},
{"id":2,"name":"LCD TV","price":50000,"imageUrl":"https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg","likes":200,"rating":4,"quantity":400},
{"id":3,"name":"OLED TV","price":100000,"imageUrl":"https://images-na.ssl-images-amazon.com/images/I/81I3YUc5eqL._AC_SL1500_.jpg","likes":300,"rating":4,"quantity":500},
{"id":4,"name":"DSLR","price":60000,"imageUrl":"https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_front.png","likes":300,"rating":4,"quantity":500},
{"id":5,"name":"Go Pro 7","price":40000,"imageUrl":"https://images-na.ssl-images-amazon.com/images/I/71nABRxZagL._AC_SL1500_.jpg","likes":300,"rating":4,"quantity":500}
];
module.exports.products = products;
