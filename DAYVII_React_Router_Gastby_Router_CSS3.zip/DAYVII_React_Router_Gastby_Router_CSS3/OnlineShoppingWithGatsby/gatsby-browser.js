import React from 'react';
import ApolloClient from "apollo-boost";
import { ApolloProvider } from "react-apollo";

var URL = "http://localhost:4000/graphql";
var client = new ApolloClient({
  uri: URL,
})

export const wrapRootElement = ({ element }) => {
  return (
    <ApolloProvider client={client}>
    {element}</ApolloProvider>
  );
}