import React from 'react';
import { useQuery } from 'react-apollo';
import ListOfProducts from '../components/listofproducts.component';
import ApolloClient, { gql } from 'apollo-boost';
import AddNewProductComponent from './newproduct';
//npm install @apollo/react-hooks
import Layout from '../components/layout';

var URL = "http://localhost:4000/graphql"

var client = new ApolloClient({
  uri: URL,
})

export const GET_ALL_PRODUCTS = gql`
  query{
    products{
      id,
      name,
      rating,
      likes,
      quantity,
      price,
      imageUrl
    }
  }
`


const HELLO_QUERY = gql`
            query{
                hello
            }`;

export const AppComponent = () => {
    // Hook which is going to make ajax request
    const {data,loading,error} = useQuery(GET_ALL_PRODUCTS);
    
    if(loading)
        return <strong>Loading..</strong>
    else
        return <Layout>
             <div className="jumbotron">
                <h1>Online Shopping</h1>
            </div>           
            <ListOfProducts allproducts={data} />   
        </Layout>      
}
export default AppComponent;