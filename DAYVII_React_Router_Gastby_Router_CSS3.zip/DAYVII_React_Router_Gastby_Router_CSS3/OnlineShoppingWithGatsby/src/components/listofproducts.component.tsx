import React, { Component } from 'react';
import ProductModel from './product.model';
import Product from './product.component';
    
export default class ListOfProducts extends Component<any,{}> {   
        static defaultProps = {
        allproducts:{products:[]}
    }
    constructor(props: any) {
        super(props);      
    }     
    render() {    
        //console.log(this.props.allproducts) ;
        var allProductsToBeCreated = this.props.allproducts.products.map((p:ProductModel) => 
        <Product productdetails={p}
        key={p.id}
         />
        );
        return <div>
           
            <div className="row">
                {allProductsToBeCreated}
                 {/* Array of <Product productdetails={p} /> */}
                {/* <Product /> */}
            </div>
        </div>
    }
}