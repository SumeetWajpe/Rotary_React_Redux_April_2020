const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---src-pages-404-tsx": hot(preferDefault(require("F:\\Trainings\\Rotary_Typescript_React_Redux_April_2020\\Gatsby\\gatsbywithtypescript\\src\\pages\\404.tsx"))),
  "component---src-pages-index-tsx": hot(preferDefault(require("F:\\Trainings\\Rotary_Typescript_React_Redux_April_2020\\Gatsby\\gatsbywithtypescript\\src\\pages\\index.tsx"))),
  "component---src-pages-newproduct-tsx": hot(preferDefault(require("F:\\Trainings\\Rotary_Typescript_React_Redux_April_2020\\Gatsby\\gatsbywithtypescript\\src\\pages\\newproduct.tsx"))),
  "component---src-pages-page-2-tsx": hot(preferDefault(require("F:\\Trainings\\Rotary_Typescript_React_Redux_April_2020\\Gatsby\\gatsbywithtypescript\\src\\pages\\page-2.tsx"))),
  "component---src-pages-posts-tsx": hot(preferDefault(require("F:\\Trainings\\Rotary_Typescript_React_Redux_April_2020\\Gatsby\\gatsbywithtypescript\\src\\pages\\posts.tsx"))),
  "component---src-pages-shoppingcart-tsx": hot(preferDefault(require("F:\\Trainings\\Rotary_Typescript_React_Redux_April_2020\\Gatsby\\gatsbywithtypescript\\src\\pages\\shoppingcart.tsx")))
}

