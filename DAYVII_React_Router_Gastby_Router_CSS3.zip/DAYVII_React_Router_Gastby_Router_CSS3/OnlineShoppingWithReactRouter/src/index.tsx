import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import * as serviceWorker from "./serviceWorker";
import BasicComponent from "./basic.component";
import PostsComponent from "./posts.component";
import { BrowserRouter, Route, Switch, Link, Redirect } from "react-router-dom";
import PostDetails from "./postdetails.component";

// ReactDOM.render(
//    <PostsComponent />  ,
//   document.getElementById('root')
// );

var routes = (
  <BrowserRouter>
  <Link to="/"> Home </Link>  | <Link to="/posts"> Posts </Link>
    <Switch>
      <Route path="/" exact component={App}></Route>
      <Route path="/posts" component={PostsComponent}></Route>
      <Route path="/postdetails/:id" component={PostDetails}></Route>

      {/* <Route path="**" render={()=><h1>Error! Error ! Error !</h1>}></Route> */}
      <Route path="**" render={()=> <Redirect to="/"></Redirect> }></Route>

    </Switch>
  </BrowserRouter>
);

ReactDOM.render(routes, document.getElementById("root"));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
