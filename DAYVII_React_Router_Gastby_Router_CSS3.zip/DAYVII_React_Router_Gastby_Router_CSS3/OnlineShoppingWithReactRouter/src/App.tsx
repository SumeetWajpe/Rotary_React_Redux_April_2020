import React from 'react';
import logo from './logo.svg';
import './App.css';
import BasicComponent from './basic.component';
import Product from './product.component';
import ProductModel from './product.model';
import ListOfProducts from './listofproducts.component';

class App extends React.Component {
  
render(){
      return <ListOfProducts  />
}















  //render() {
    // return <div>
    //   <BasicComponent msg="Hi"/>
    //   <BasicComponent msg="Hola" />
    //   <BasicComponent msg="Namaste" />
    //   <BasicComponent  />
    // </div>   
 // }
}
export default App;
