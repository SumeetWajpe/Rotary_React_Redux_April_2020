import React from "react";
import axios from "axios";

export class PostDetails extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = { postDetails: {} };
  }
  componentDidMount() {
    // make ajax request !
    var {
      match: { params },
    } = this.props;
    console.log(params.id);
    let thePromise = axios.get(
      "https://jsonplaceholder.typicode.com/posts/" + params.id
    );
    thePromise.then(
      (response) => {
        // setState !
        this.setState({ postDetails: response.data });
      },
      (err) => {
        console.log(err);
      }
    );
  }
  render() {
    return (
      <div>
        <h1> Post Details </h1>
        <h3>Id : {this.state.postDetails.id} </h3>
        <h3>User Id : {this.state.postDetails.userId} </h3>
        <h3>Title : {this.state.postDetails.title} </h3>
        <h3>Body : {this.state.postDetails.body} </h3>
      </div>
    );
  }
}

export default PostDetails;
