import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import BasicComponent from './basic.component';
import PostsComponent from './posts.component';
import ApolloClient from 'apollo-boost';
import { ApolloProvider } from 'react-apollo';
import gql from 'graphql-tag';
import AppComponent from './AppWithuseQueryHook';
import { BrowserRouter, Link, Switch, Route, Redirect } from 'react-router-dom';
import AddNewProductComponent from './addproduct.component';

var URL = "http://localhost:4000/graphql";

var client = new ApolloClient({
  uri: URL
});

// client.query({
//   query: gql`
//         query{
//             hello
//         }
//   `}).then(result => console.log(result));

ReactDOM.render(
  <ApolloProvider client={client}>  
    {/* <App />     */}

   <BrowserRouter>
  
<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link className="navbar-brand" to="/">Shopping Cart Router & GraphQL App </Link>
    </div>
    <ul className="nav navbar-nav">
      <li className="active"><Link to="/">Home</Link></li> 
      <li><Link to="/newproduct">New Product</Link></li> 

      <li><Link to="/posts">Posts</Link></li> 

    </ul>
  </div>
</nav>
    <Switch>
      <Route path="/" exact component={AppComponent}></Route>
      <Route path="/posts" component={PostsComponent}></Route>   
      <Route path="/newproduct" component={AddNewProductComponent}></Route>     

      {/* <Route path="**" render={()=><h1>Error! Error ! Error !</h1>}></Route> */}
      <Route path="**" render={()=> <Redirect to="/"></Redirect> }></Route>

    </Switch>
  </BrowserRouter>
  </ApolloProvider>
  ,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
