import {createStore} from 'redux';
import {rootReducer} from '../reducers/root.reducer';


var initialStoreData:any = {
    products:[],
    posts:[{id:1,title:'Using Router With Redux'}]
}

// createStore(reducer,initialstoredata)  -> redux !
export var store = createStore(rootReducer,initialStoreData);

