import React from 'react';
import ProductModel from '../product.model';
interface IProductProps {
    productdetails: ProductModel;
    IncreaseLikesCount: (theId: number) => any;
    RemoveProduct: (theId: number) => any;
}
//React.Component<PropTypes,StateTypes>
export default class Product extends React.Component<IProductProps>{
    render() {
        return <div className="col-md-4">
            <div className="ProductStyle">
                <h1>{this.props.productdetails.name} </h1>
                <img src={this.props.productdetails.imageUrl} height="200px" width="200px" /> <br />
                <h4>Price: {this.props.productdetails.price}</h4>
                <h4>Rating: {this.props.productdetails.rating}</h4>
                <h4>Quantity: {this.props.productdetails.quantity} </h4>
                <button className="btn btn-primary"
                    onClick={() => this.props.IncreaseLikesCount(this.props.productdetails.id)} >
                    <span className="glyphicon glyphicon-thumbs-up">
                    </span>
                    {this.props.productdetails.likes}
                </button>
                <button className="btn btn-danger" onClick={() => this.props.RemoveProduct(this.props.productdetails.id)}>
                    <span className="glyphicon glyphicon-trash">
                    </span>
                </button>
            </div>
        </div>

    }
}