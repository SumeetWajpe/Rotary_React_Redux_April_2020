import React, { useState } from 'react';
import { gql } from 'apollo-boost';
import { useMutation, Mutation } from 'react-apollo'; //@apollo/react-hooks
import {GET_ALL_PRODUCTS} from './App';

const ADD_PRODUCT = gql`
mutation  ProductMutation(
    $id: ID!
    $name: String!
    $likes: Int
    $imageUrl: String
    $price: Int!
    $quantity:Int
    $rating: Int
){
    createProduct(
        id: $id
        name: $name
        likes: $likes
        imageUrl: $imageUrl
        price: $price
        quantity: $quantity
        rating: $rating
    ){
        name
    }
}
`

export const AddNewProductComponent = () => {
    const [newProduct, setNewProduct] = useState({
        id: 0,
        name: "",
        likes: 0,
        quantity: 0,
        rating: 0,
        imageUrl: "",
        price: 0
    });

    const [createProductMutationMethod,{data,loading,error}] = useMutation(ADD_PRODUCT,{
        refetchQueries:[{query:GET_ALL_PRODUCTS}]
    });
    return (
        <form onSubmit={(e:any)=>{            
                e.preventDefault();
                createProductMutationMethod({variables:{...newProduct}});// actually mutating - fire query
                e.target.reset();            
        }}>              
            Id: <input type="number" className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, id: +(e.target.value) })} />
            Name: <input type="text" className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} />
              Price: <input type="number" className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, price: +(e.target.value) })} />
              Quantity: <input type="number" className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, quantity: +(e.target.value) })} />
              Rating: <input type="number" className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, rating: +(e.target.value) })} />
              Likes: <input type="number" className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, likes: +(e.target.value) })} />
              Image Url : <input type="text" className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, imageUrl: e.target.value })} />
            <button className="btn btn-success" 
           
            >
                <span className="glyphicon glyphicon-plus-sign">

                </span>
            </button>

        </form>
    )
}

export default AddNewProductComponent;