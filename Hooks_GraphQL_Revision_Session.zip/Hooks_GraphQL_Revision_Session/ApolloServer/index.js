var express = require('express');
var {ApolloServer,gql} = require('apollo-server-express');
var dbProducts = require('./db').products;
// rootQuery -> every query is routed through 
// customTypes -> Object Types which define our data
// resolvers -> fetch & return the data (functions)
const typeDefs = gql`
#rootQuery
type Query{
    hello:String,
    products:[Product],
    product(id: ID):Product
}

type Product{
    id:ID!,
    name:String,
    likes:Int,
    imageUrl:String,
    price:Int,
    quantity:Int,
    rating:Int
}

type Mutation{
    createProduct(id: ID!, name: String!,likes: Int,imageUrl: String,price: Int!,quantity: Int,rating:Int):Product
}
`;
const resolvers = {
    Query:{
        hello:()=> 'Hello GraphQL !',
        products:(parent,args,context,info)=>{
            // DB connectivity
            // REST (axios) - 3rd Party/ other apis
            return dbProducts;
        },
        product:(parent,{id},context,info)=>{
            return dbProducts.find(p => p.id === parseInt(id));
        }
    },
    Mutation:{
        createProduct:(parent,{id,name,likes,quantity,price,rating,imageUrl},context,info)=>{
            const newProduct = {id,name,likes,quantity,price,rating,imageUrl}; // enhanced literal syntax
            dbProducts.push(newProduct);// insert 
            return newProduct;
        }
    }
};
var server = new ApolloServer({typeDefs,
    resolvers});
var app =  express(); // represent our app
server.applyMiddleware({app});
app.listen({port:4000},()=>{
        console.log('ApolloServer runnning at localhost:4000'+server.graphqlPath);
});