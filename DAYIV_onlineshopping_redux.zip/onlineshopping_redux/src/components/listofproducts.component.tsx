import React, { Component } from 'react';
import ProductModel from '../product.model';
import Product from './product.component';
import axios from 'axios';

export default class ListOfProducts extends Component<any,{}> {   
    componentDidMount(){
        axios.get('./productsdata.json').then(
            (response)=> this.props.FetchProducts(response.data)
        )
    }
    render() {     
       // console.log(this.props);
        var allProductsToBeCreated = this.props.allproducts.map((p:ProductModel) =>
        
            <Product productdetails={p}   
            IncreaseLikesCount={(theId:number)=>this.props.IncrementLikes(theId)} 
            RemoveProduct={(theId:number)=>this.props.DeleteProduct(theId)}   key={p.id} />
        );
        return (<div>
            <div className="jumbotron">
                <h1>Online Shopping</h1>
            </div>

            <div className="row">
                {allProductsToBeCreated} {/* Array of <Product productdetails={p} /> */}              
            </div>
        </div>)
    }
}