import {createStore} from 'redux';
import {rootReducer} from '../reducers/root.reducer';


var initialStoreData:any = {
    products:[],
    posts:[]
}

// createStore(reducer,initialstoredata)  -> redux !
export var store = createStore(rootReducer,initialStoreData);

