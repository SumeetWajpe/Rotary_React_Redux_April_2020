import ProductModel from "../product.model";

 const INCREMENT_LIKES = 'INCREMENT_LIKES';
 const DELETE_PRODUCT = 'DELETE_PRODUCT';
 const ADD_PRODUCT = 'ADD_PRODUCT';
 const DELETE_POST = 'DELETE_POST';
 const FETCH_PRODUCTS = 'FETCH_PRODUCTS';


// action Creator !
export function IncrementLikes(theId:number){
    return {type:INCREMENT_LIKES,theId};
}

export function DeleteProduct(theId:number){
    return {type:DELETE_PRODUCT,theId};
}

export function FetchProducts(response:ProductModel){
    return {type:FETCH_PRODUCTS,response};
}

export function AddProduct(){
    return {type:ADD_PRODUCT};
}

export function DeletePost(){
    return {type:DELETE_POST};
}