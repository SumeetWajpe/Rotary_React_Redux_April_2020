import React, { useState } from 'react'

// Hooks are 16.8 feature !
// State Hook which allows to define state and mutate it using Hooks

interface ICounterProps{
    initialCount:number;
}

export const Counter = (props:ICounterProps) => {
    const [count,setCount] = useState(props.initialCount);
    const [age,setAge] = useState(30);
    const [company,setCompany]=useState({name:'Bitcoin'});
    return(
        <div>         
           <button onClick={()=>setCount(count+1)}> {count}</button>
           <button onClick={()=>setAge(age+10)}> {age}</button>
        </div>
    )
}

export default Counter;