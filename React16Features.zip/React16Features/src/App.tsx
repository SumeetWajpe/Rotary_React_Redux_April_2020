import React from 'react';
import logo from './logo.svg';
import './App.css';
import Counter from './stateHook';
import EffectHookDemo from './effectHook';

function App() {
  return (
    // <div className="App">
    //   <Counter initialCount={100} />
    // </div>
    <div className="App">
        <EffectHookDemo />
  </div>
  );
}

export default App;
