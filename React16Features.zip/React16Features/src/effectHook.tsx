import React, { useState, useEffect } from 'react'
import axios from 'axios';

export const EffectHookDemo = () => {
    const [posts,setPosts] = useState([]);
    const [message,setMessage] = useState('Loading..');    
    useEffect(()=>{    
        axios.get('https://jsonplaceholder.typicode.com/posts')
        .then((response)=>{ 
                setPosts(response.data);   
                setMessage('');            
            },
            (err)=>{console.log(err)}
        )
    },[]);    
    var postsToBeCreated = posts.map((p:any)=> <li key={p.id}>{p.title}</li>);  
    return(         
        <div>
            <h1>All Posts</h1>
             <ul>
                {message}
                {postsToBeCreated}
            </ul>
        </div>
    )
}

export default EffectHookDemo;