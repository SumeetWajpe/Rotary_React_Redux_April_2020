let es6var = 100;
const PIE = 3.14;
var Square = x => x * x;
