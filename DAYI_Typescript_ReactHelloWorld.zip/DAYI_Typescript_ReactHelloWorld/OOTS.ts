// Enumerations
enum Designation {
    Developer = 100,
    Tester,
    Architect,
    TeamLead
}
var d = Designation.Architect;
// console.log(d); // number
console.log(Designation[d]); // string representaion


// Interfaces
interface IsEnterprise {
    isTaxable: boolean;
}

interface ICompany {
    name: string;
    city?: string;
    getDetails?(): void;
}

// Literal syntax
//var company:ICompany = {name:'Accenture'};


// Interfaces with Classes
class Company implements ICompany, IsEnterprise {
    isTaxable: boolean;
    name: string;
    city: string;
    getDetails() {
        console.log(`${this.name} is in ${this.city} !`);
    }
}

var comp: Company = new Company();

// Using own custom constructor
// function Emp(){
//     this.salary = 20000;
// }

// function  Manager() {
//     this.incentives = 50000;
// }

// Manager.prototype = new Emp();

// var mgr = new Manager();
// console.log(mgr.salary);

// Classes
//private | public | protected (members)
class Car {
    // private id:number;
    protected id:number;
    name: string;
    speed: number;

    constructor(name: string = "i20", speed: number = 100) {
        this.name = name;
        this.speed = speed;
    }
    accelerate(): string {
        //return "The car " + this.name + " is running @ " + this.speed + " kmph !";
        return `The car ${this.name} is running @ ${this.speed} kmph !`; // String template
    }
}
// var carObj:Car = new Car();
// console.log(carObj.accelerate());

// var multiLineStr = `First Line
// Second Line
// Last Line !`;
// console.log(multiLineStr);

class JamesBondCar extends Car {
    canFly: boolean;
    useNitro: boolean;
    constructor(n: string, s: number, fly: boolean, nitro: boolean) {
        super(n, s); // invoke the parameterized base class ctor !
        this.canFly = fly;
        this.useNitro = nitro;
    }
    accelerate(): string {       
        return `${super.accelerate()}  Can It Fly ? : ${this.canFly}`;
    }
}

var jbc = new JamesBondCar("Aston Martin", 500, true, true);

console.log(jbc.accelerate());

// Generics
 var moreCars:Array<string> = new Array<string>("TATA",'MARUTI');
 var allcarObjs:Array<Car> = new Array<Car>();
 allcarObjs.push(new Car("i30",300));

 // Generics function
 function Swap<T,>(x:T,y:T):T{
     let t;    
     t = x;
     x = y;
     y = t;
     return t;
 }
 var r = Swap<number>(10,20);
// Generics Classes
 class Point<T>
 {
     x:T;
     y:T
 }

 var pt:Point<number> = new Point<number>();
 
 var pt2:Point<string> = new Point<string>();


 // Enhanced Class Syntax
// Used for model classes
 class EnhancedCar{
     constructor(private id?:number,public name:string="i20",public speed:number=100){

     }
 }

 var ec = new EnhancedCar();


