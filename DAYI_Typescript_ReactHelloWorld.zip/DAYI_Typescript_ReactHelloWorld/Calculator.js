"use strict";
exports.__esModule = true;
var Math_1 = require("./Math"); // Selective import
console.log(Math_1.Add(20, 30));
// OR 
// import * as MathFuncs from './Math'; // imports everything
// console.log(MathFuncs.Add(20,30));
// console.log(MathFuncs.Subtract(50,30));
