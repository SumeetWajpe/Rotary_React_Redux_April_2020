//var message = "Hello World !"; // Type inference
//message= 100;
var message; // Type Annotation
message = "Hello Typescript !";
console.log(message);
var b;
var s;
var n;
var o;
var a;
a = 100;
a = "Dynamic Type !";
a = true;
a = { name: 'Typescript' };
a = [10, 20, 30];
// if(true){
//     let x;
//     x = 100;
//     // 100 lines of code
//     // let x = 200; // Error redefining x
//     console.log(x);
// }
var PI = 3.14; // definition mandatory
// PI = 3.14536; // Error !
// Arrays
var k, l;
// var cars:string[] = ['BMW','AUDI','Porche'];
// var moreCars:Array<string> = new Array<string>("TATA",'MARUTI');
// function Add(x,y){
//     return x + y;
// }
//    Add(); // Error in Typescript | but allowed in javascript
// Functions
// Function Declaration
// function Addition(x:number,y:number):number | string{
//     if(x<0){
//         return ' x should be greater than zero !';
//     }
//     return x + y;
// }
// var result:number | string = Addition(10,20);
// Function As Expression
// var AdditionasExpr = function(x:number,y:number):number{
//     return x + y;
// }
// Function parameters : Optional / Default / Rest
// Optional Parameters
// function PrintBooks(author?:string,title?:string,noOfCopies?:number){
//     author = author || "Ranjit Desai"; // js way ! 
//     console.log(author,title,noOfCopies);
// }
//PrintBooks();
// Default Parameters
// function PrintBooks(author:string="Unknown",title:string="Unknown",noOfCopies:number=1){    
//     console.log(author,title,noOfCopies);
// }
// PrintBooks();
// PrintBooks("Ranjit Desai","Mrtyunjay",10);
// PrintBooks(undefined,"Another Unknown Title",20);
// Rest arguments
// function PrintBooks(author:string,...titles:string[]){
//         console.log(author,titles);
// }
// PrintBooks("Unknown");
// PrintBooks("Dr. APJ Abdul Kalam","India 2020","Wings Of Fire");
// PrintBooks("Ranjit Desai","Mrutyunjay","Radhey","Chava");
// function Square(x){
//     return x * x;
// }
// var Square = function(x){
//     return x * x;
// }
// Arrow Function [ES6]
// var Square = (x)=>{
//     return x * x;
// }
// OR
// var Square = x => x  * x;
// var Square = (x:number):number => x * x;
// console.log(Square(10));
// var Addition = (x:number,y:number):number => x + y;
// console.log(Addition(20,40));
// cars.forEach(function(theCar){
//     console.log(theCar);
// });
// // as an arrow function
// cars.forEach(theCar=>console.log(theCar));
//  ES 5 way using closures !
// function Emp(){
//     this.salary = 50000;
//     var self = this;
//     setTimeout(function(){
//             console.log(self.salary);
//     },2000);
// }
// var e = new Emp();
// Arrow function context(this) gets binded at the time 
//of creation of the arrow function
// function Emp(){
//     this.salary = 50000;         
//     setTimeout(()=>{           
//             console.log(this.salary);
//     },2000);
// }
// var e = new Emp();
// Operators
// Spread Operator with Arrays
// var cars:string[] = ['BMW','AUDI','Porche'];
// var moreCars:Array<string> = new Array<string>("TATA",'MARUTI');
// cars[0] = "XYZ"; // not reflected in allCars
// var allCars = [...cars,...moreCars,"Hyundai"]; // Spread Operator
// console.log(allCars);
// Spread Operator with Objects
// var person = {name:'Virat',city:'Delhi'};
// var player = {...person,runs:40000};
// console.log(player.name);
// Destructuring with Arrays
// var cars:string[] = ['BMW','AUDI','Porche',"Hyundai"];
// // var carOne,carTwo,lastCar;
// [carOne,,carTwo,lastCar="TATA"] = cars;
// var [carOne,,carTwo,lastCar="TATA"] = cars;
// console.log(carOne);
// console.log(lastCar);
// Destructuring with Objects
// var player = {city:'Delhi',runs:40000,fname:'Virat'};
// var fname,city,runs; 
// ({fname,runs,city} = player);
// console.log(fname);
// Enhanced Object Literal Syntax
var fname = "Virat";
var city = "Delhi";
var runs = 40000;
// var player = {city:city,runs:runs,fname:fname};
//OR
var player = { city: city, runs: runs, fname: fname };
