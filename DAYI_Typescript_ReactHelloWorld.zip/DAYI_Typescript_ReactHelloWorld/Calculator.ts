//  import {Add,PI} from './Math'; // Selective import
//  console.log(Add(20,30));
// OR 
// import * as MathFuncs from './Math'; // imports everything
// console.log(MathFuncs.Add(20,30));
// console.log(MathFuncs.Subtract(50,30));

// alias
// import BinOp,{Subtract} from './Math';
import BinOp from './Math';
var bop = new BinOp();
console.log(bop.addition(20,30));