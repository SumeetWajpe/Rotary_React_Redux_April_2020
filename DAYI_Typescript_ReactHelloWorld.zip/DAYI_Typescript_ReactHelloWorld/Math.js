"use strict";
exports.__esModule = true;
function Add(x, y) {
    return x + y;
}
exports.Add = Add;
function Product(x, y) {
    return x * y;
}
exports.Product = Product;
function Divide(x, y) {
    return x / y;
}
exports.Subtract = function (x, y) {
    return x - y;
};
exports.PI = 3.14;
// export variables,const,class,enum,interfaces
