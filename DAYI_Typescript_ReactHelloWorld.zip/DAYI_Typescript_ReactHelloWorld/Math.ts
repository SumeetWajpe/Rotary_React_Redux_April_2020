export function Add(x:number,y:number){
    return x + y;
}
export function Product(x:number,y:number){
    return x * y;
}
function Divide(x:number,y:number){
    return x / y;
}
export var Subtract = (x:number,y:number)=>{
    return x - y;
}
export const PI:number = 3.14;
// export variables,const,class,enum,interfaces!
// per module only one default export  !
export default class BinaryOperations{
    addition(x,y){
        return x + y+100;
    }
}
