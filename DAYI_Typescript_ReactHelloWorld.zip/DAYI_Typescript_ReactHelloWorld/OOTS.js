var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// Enumerations
var Designation;
(function (Designation) {
    Designation[Designation["Developer"] = 100] = "Developer";
    Designation[Designation["Tester"] = 101] = "Tester";
    Designation[Designation["Architect"] = 102] = "Architect";
    Designation[Designation["TeamLead"] = 103] = "TeamLead";
})(Designation || (Designation = {}));
var d = Designation.Architect;
// console.log(d); // number
console.log(Designation[d]); // string representaion
// Literal syntax
var company = { name: 'Accenture' };
// Using own custom constructor
// function Emp(){
//     this.salary = 20000;
// }
// function  Manager() {
//     this.incentives = 50000;
// }
// Manager.prototype = new Emp();
// var mgr = new Manager();
// console.log(mgr.salary);
// Classes
//private | public | protected (members)
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        //return "The car " + this.name + " is running @ " + this.speed + " kmph !";
        return "The car " + this.name + " is running @ " + this.speed + " kmph !"; // String template
    };
    return Car;
}());
// var carObj:Car = new Car();
// console.log(carObj.accelerate());
// var multiLineStr = `First Line
// Second Line
// Last Line !`;
// console.log(multiLineStr);
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(n, s, fly, nitro) {
        var _this = _super.call(this, n, s) || this;
        _this.canFly = fly;
        _this.useNitro = nitro;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + " Can It Fly ? : " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 500, true, true);
console.log(jbc.accelerate());
