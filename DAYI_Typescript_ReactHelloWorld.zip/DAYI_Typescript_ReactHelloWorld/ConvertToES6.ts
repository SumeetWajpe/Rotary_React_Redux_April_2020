let es6var:number = 100;
const PIE = 3.14;
var Square = (x:any) => x * x;