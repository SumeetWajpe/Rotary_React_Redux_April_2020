import React from 'react';
import ProductModel from './product.model';
interface IProductProps {
    productdetails: ProductModel
}
export default class Product extends
    React.Component<IProductProps>{
    static defaultProps = {
        productdetails: new ProductModel("Unknown", 0, "https://www.indiaspora.org/wp-content/uploads/2018/10/image-not-available.jpg", 0, 0, 0)
    }
    IncrementLikes(){
        this.props.productdetails.likes+=1; // props are readonly !!
    }
    render() {
        return <div className="col-md-4">
            <div className="ProductStyle">
                <h1>{this.props.productdetails.name} </h1>
                <img src={this.props.productdetails.imageUrl} height="200px" width="200px" /> <br />
                <h4>Price: {this.props.productdetails.price}</h4>
                <h4>Rating: {this.props.productdetails.rating}</h4>
                <h4>Quantity: {this.props.productdetails.quantity} </h4>
                <button className="btn btn-primary" onClick={this.IncrementLikes.bind(this)}>
                    <span className="glyphicon glyphicon-thumbs-up">

                    </span>
                    {this.props.productdetails.likes}
                </button>
            </div>
        </div>

    }
}