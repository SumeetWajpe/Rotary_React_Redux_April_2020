import React, { Component } from 'react';
import ProductModel from './product.model';
import Product from './product.component';

export default class ListOfProducts extends Component {
    private productslist: ProductModel[] = [];

    constructor(props: any) {
        super(props);
        this.productslist = [
            new ProductModel("LED TV", 40000, "https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg", 100, 3, 200),
            new ProductModel("LCD TV", 50000, "https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg", 200, 4, 400),
            new ProductModel("OLED TV", 100000, "https://images-na.ssl-images-amazon.com/images/I/81I3YUc5eqL._AC_SL1500_.jpg", 300, 4, 500),
            new ProductModel("DSLR", 60000, "https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_front.png", 300, 4, 500),
            new ProductModel("Go Pro 7", 40000, "https://images-na.ssl-images-amazon.com/images/I/71nABRxZagL._AC_SL1500_.jpg", 300, 4, 500)
        ];
    }

    render() {

        var allProductsToBeCreated = this.productslist.map(p => <Product productdetails={p} />);

        return <div>
            <div className="jumbotron">
                <h1>Online Shopping</h1>
            </div>

            <div className="row">
                {allProductsToBeCreated} {/* Array of <Product productdetails={p} /> */}
                {/* <Product /> */}
            </div>
        </div>
    }
}