module.exports = {
  purge: [],
  theme: {
    extend: {},
  },
  variants: {
    backgroundColor:['hover','focus','active']
  },
  plugins: [],
}
