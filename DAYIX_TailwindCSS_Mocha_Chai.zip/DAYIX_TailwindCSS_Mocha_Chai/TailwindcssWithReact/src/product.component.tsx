import React from 'react';
import ProductModel from './product.model';

interface IProductProps {
    productdetails: ProductModel;
    DeleteHandler:(theId:number)=>void;
}
interface IProductState {
    currLikes: number
}
//React.Component<PropTypes,StateTypes>
export default class Product extends
    React.Component<IProductProps, IProductState>{
    constructor(props: IProductProps) {
        //console.log('Inside constructor of Products')
        super(props);
        this.state = { currLikes: this.props.productdetails.likes };
    }
    static defaultProps = {
        productdetails: new ProductModel(0,"Unknown", 0, "https://www.indiaspora.org/wp-content/uploads/2018/10/image-not-available.jpg", 0, 0, 0)
    }
    IncrementLikes() {
        // this.props.productdetails.likes+=1; // props are readonly !!
        // update the state !
        //this.state.count+=1; // state is immutable !!
        this.setState({ currLikes: this.state.currLikes + 1 });
    }
    componentWillUnmount(){
        // clean up !
        console.log('componentWillUnmount -> Product')
    }
    render() {
        return <div className="max-w-sm rounded overflow-hidden shadow-lg my-4">
          <img className="w-full" src={this.props.productdetails.imageUrl} alt="Image for Respective Product" />
          <div className="px-6 py-4">
            <div className="font-bold text-xl mb-2">{this.props.productdetails.name}</div>
            <p className="text-gray-700 text-base">
            <strong>Price: </strong> {this.props.productdetails.price} <br/>
                        <strong>Rating: </strong> {this.props.productdetails.rating} <br/>
                        <strong>Quantity: </strong>{this.props.productdetails.quantity} <br/>
                        <button 
                        className="btn-teal hover:bg-teal-500 hover:text-white focus:outline-none focus:shadow-outline active:bg-teal-700"
                         onClick={this.IncrementLikes.bind(this)}> 
                        {this.state.currLikes}
                      </button>
                      <button className="btn-teal" 
                      onClick={()=>this.props.DeleteHandler(this.props.productdetails.id)}>
                       {/* onClick={this.props.DeleteHandler.bind(this,this.props.productdetails.id)}> */}          
        
                            X                       
                      </button>
            </p>
          </div>  
        </div>
       

    }
}

