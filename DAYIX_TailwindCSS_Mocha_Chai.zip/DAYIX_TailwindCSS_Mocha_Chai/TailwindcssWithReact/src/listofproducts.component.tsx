import React, { Component } from 'react';
import ProductModel from './product.model';
import Product from './product.component';
import axios from 'axios';

interface IListOfProductsState{
    productslist:ProductModel[];
}
export default class ListOfProducts extends Component<{},IListOfProductsState> {
    state: { productslist: ProductModel[]; };  
    constructor(props: any) {
        super(props);
        console.log('Constructor of ListOfProducts');
        this.state = {productslist : []};      
    }
    componentWillMount(){
        // any initialization logic !
       // console.log('Inside componentWillMount');
    }
    componentDidMount(){
        // any logic to be executed after DOM creation
        // 100% sure DOM is ready !
        //console.log('Inside componentDidMount');
        // REST / Webapi -> Fetching data ! (Server)
        axios.get('./productsdata.json').then(
            (response)=>this.setState({productslist:response.data}),
            (err)=>console.log(err)
        );
    }

    shouldComponentUpdate(){
        //console.log('Inside shouldComponentUpdate');
        //console.log(this.state);
        //console.log(arguments);
        if(arguments[1].productslist.length ==0){
            return false;
        }
        return true;
    }
    componentWillUpdate(){
        //console.log('Inside componentWillUpdate');
       // console.log(this.state);
    }
    componentDidUpdate(){
       // console.log('Inside componentDidUpdate');
    } 

    DeleteAnItemFromList(theId:number){
        //console.log('DeleteAnItemFromList of ListOfProducts');

        // delete a record from the array !
         // this.setState(...)     
        let newProductlist = this.state.productslist.filter(p=> p.id !== theId);     
        this.setState({productslist:newProductlist});
    }
    render() {
       // console.log('Render of ListOfProducts');
        //console.log(this.state);

        var allProductsToBeCreated = this.state.productslist.map(p => 
        <Product productdetails={p}
        key={p.id}
        DeleteHandler={(id)=>this.DeleteAnItemFromList(id)}
         />
        );

        return <div className="mx-64">
            <div className="font-extrabold text-6xl m-12 h-32 w-full bg-gray-300 border rounded-lg text-center">
                <h1>Online Shopping</h1>
            </div>

            <div className="min-h-10 grid grid-cols-3 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3">
                {allProductsToBeCreated} {/* Array of <Product productdetails={p} /> */}
                {/* <Product /> */}
            </div>
        </div>
    }
}

