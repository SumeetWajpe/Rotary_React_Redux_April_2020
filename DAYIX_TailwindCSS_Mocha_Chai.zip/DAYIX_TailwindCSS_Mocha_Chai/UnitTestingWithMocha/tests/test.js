var assert = require('assert'); // node assert library

//describe -> test suite
// context -> currentExecution
// it -> unit test

describe('a test suite',()=>{
    context('function to be tested',()=>{

        before(()=>{
            console.log("====== before ======");
        });
        beforeEach(()=>{
            console.log("====== beforeEach ======");
        });
        after(()=>{
            console.log("====== after ======");
        });
        afterEach(()=>{
            console.log("====== afterEach ======");
        });

        it('should test equality',()=>{
            assert.equal(10,10);// assertions 
        });
        it('should test equality of objects',()=>{
            assert.deepEqual({name:'React'},{name:'React'});// assertions 
        });
    });
});