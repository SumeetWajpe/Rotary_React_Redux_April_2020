const chai = require('chai');
const source = require('../src/src');
const expect = chai.expect;

xdescribe('test suite with chai assertions',()=>{
    context('ctx for unit test with chai',()=>{
        it('should compare two values',()=>{
            expect(10).to.equal(10);
        });
        it('should compare two objects',()=>{
            expect({name:'React'}).to.deep.equal({name:'React'});
        });
        it('more assertions',()=>{
            expect({name:'React'}).to.have.property('name').to.equal('React');
            expect(5>8).to.be.false;
            expect({}).to.be.an('object');
            expect(10).to.be.a('number');
            expect(null).to.be.null;
            expect(1).to.exist;
        });
    });
});

describe('test suite with chai assertions for js code',()=>{
    context('ctx for unit test with chai for js code',()=>{
        it('should compare two values with Add()',()=>{
            expect(source.Add(10,20)).to.equal(30);
        });       
    });
});