import React from "react"


export const Layout = props => {
  return (
    <div>
      <header style={{border:'2px solid red',backgroundColor:'lightblue'}}>
        <h1>Welcome to Gatsby !</h1>
      </header>
      {props.children}
      <footer style={{border:'1px solid red',backgroundColor:'lightgreen'}}>Copyright @ 2020 , Rotary Int !</footer>
    </div>
  )
}

export default Layout;
