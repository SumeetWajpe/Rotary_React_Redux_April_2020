import React from "react"
import { Layout } from "../components/layout";

export const AboutComponent = () => {
  return (
    <Layout>
      <div>
        <strong> This is About Component ! (Page)</strong>
      </div>
    </Layout>
  )
}

export default AboutComponent
