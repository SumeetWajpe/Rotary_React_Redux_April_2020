import React from "react";
import {Link} from 'gatsby';
import Layout from "../components/layout";

export default () => {
  return (
    <Layout>
        <div>
        {/* <a href="/about">About </a> | <a href="/contact">Contact</a><br/> */}
        <Link to="/about">About</Link> |
        <Link to="/contact">Contact</Link> <br/>  
      <strong>Hello world!</strong>
    </div>
    </Layout>
  )
}
