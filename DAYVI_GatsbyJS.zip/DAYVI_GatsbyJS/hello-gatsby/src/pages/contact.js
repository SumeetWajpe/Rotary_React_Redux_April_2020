import React from "react"
import Layout from "../components/layout"

export const ContactComponent = props => {
  return (
    <Layout>
      <div>
        <strong>Inside Contact Component</strong>
      </div>
    </Layout>
  )
}

export default ContactComponent
