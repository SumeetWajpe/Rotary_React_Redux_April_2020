import React from "react"
import { Link } from "gatsby"

export const Nav = () => {
  return (
    <div>

<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link className="navbar-brand" to="/">Gatsby App</Link>
    </div>
    <ul className="nav navbar-nav">
      <li className="active"><Link to="/">Home</Link></li>
      <li><Link to="/page-2/">Go to page 2</Link></li>
      <li><Link to="/posts">Posts</Link></li>
      <li><Link to="/app">Shopping Cart</Link></li>

  
    </ul>
  </div>
</nav>

    </div>
  )
}

export default Nav
