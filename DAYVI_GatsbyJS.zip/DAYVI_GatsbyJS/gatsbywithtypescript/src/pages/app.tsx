import React from 'react';
import {GET_ALL_PRODUCTS} from './App';
import { useQuery } from 'react-apollo';
import ListOfProducts from './listofproducts.component';
import { gql } from 'apollo-boost';
import AddNewProductComponent from './addproduct.component';
//npm install @apollo/react-hooks


const HELLO_QUERY = gql`
            query{
                hello
            }`;

export const AppComponent = () => {
    // Hook which is going to make ajax request
    const {data,loading,error} = useQuery(GET_ALL_PRODUCTS);
    
    if(loading)
        return <strong>Loading..</strong>
    else
        return <React.Fragment>
             <div className="jumbotron">
                <h1>Online Shopping</h1>
            </div>
            <AddNewProductComponent/>
            <ListOfProducts allproducts={data} />   
        </React.Fragment>      
}
export default AppComponent;